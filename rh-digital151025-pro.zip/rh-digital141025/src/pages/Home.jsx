import React from "react";
function Home() {
  return (
    <div style={{ padding: "2rem" }}>
      <h1>Bem-vindo ao RH Digital</h1>
      <p>Esta é a página inicial.</p>
    </div>
  );
}
export default Home;