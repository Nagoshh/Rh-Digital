import React from "react";
function Vagas() {
  return (
    <div style={{ padding: "2rem" }}>
      <h1>Vagas</h1>
      <p>Lista de vagas será exibida aqui.</p>
    </div>
  );
}
export default Vagas;